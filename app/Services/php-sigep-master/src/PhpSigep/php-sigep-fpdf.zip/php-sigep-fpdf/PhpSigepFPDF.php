<?php

require_once __DIR__ . '/fpdi.php';

class PhpSigepFPDF extends FPDISigep
{
}
