<?php

namespace PhpSigep\Pdf\Exception;

class InvalidChancelaEntry extends \PhpSigep\Exception
{
    
}