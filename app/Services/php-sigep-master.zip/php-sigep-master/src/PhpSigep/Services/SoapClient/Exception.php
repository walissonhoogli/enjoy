<?php
namespace PhpSigep\Services\SoapClient;

/**
 * @author: Stavarengo
 */
class Exception extends \Exception
{

}