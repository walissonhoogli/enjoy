<?php


namespace PhpSigep\Services;


/**
 * @author: Stavarengo
 */
class InvalidArgument extends \PhpSigep\Exception
{

}