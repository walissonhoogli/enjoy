<?php
/**
 * php-sigep Project ${PROJECT_URL}
 *
 * @link      ${GITHUB_URL} Source code
 */

namespace PhpSigep\Services\Real\Exception;

class SoapExtensionNotInstalled extends \Exception
{

}
