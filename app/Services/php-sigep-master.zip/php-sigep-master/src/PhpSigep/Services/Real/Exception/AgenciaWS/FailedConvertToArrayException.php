<?php
namespace PhpSigep\Services\Real\Exception\AgenciaWS;

/**
 * @author: Cristiano Soares
 * @link: http://comerciobr.com
 */
class FailedConvertToArrayException extends \PhpSigep\Exception
{
}