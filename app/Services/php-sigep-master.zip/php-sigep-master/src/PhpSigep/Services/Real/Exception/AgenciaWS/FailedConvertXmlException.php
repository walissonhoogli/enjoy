<?php
namespace PhpSigep\Services\Real\Exception\AgenciaWS;

/**
 * @author: Cristiano Soares
 * @link: http://comerciobr.com
 */
class FailedConvertXmlException extends \PhpSigep\Exception
{
}