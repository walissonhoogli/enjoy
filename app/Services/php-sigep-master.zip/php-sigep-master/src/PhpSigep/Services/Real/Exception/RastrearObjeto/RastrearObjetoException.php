<?php


namespace PhpSigep\Services\Real\Exception\RastrearObjeto;


/**
 * @author: Stavarengo
 */
class RastrearObjetoException extends \PhpSigep\Exception
{

}