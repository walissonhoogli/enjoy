<?php
namespace PhpSigep\Services\Real\Exception\SolicitaXmlPlp;

/**
 * @author: Cristiano Soares
 * @link: http://comerciobr.com
 */
class FailedConvertToArrayException extends \PhpSigep\Exception
{
}