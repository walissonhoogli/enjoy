<?php


namespace PhpSigep\Services\Real\Exception\RastrearObjeto;


/**
 * @author: Stavarengo
 */
class TipoInvalidoException extends \PhpSigep\Exception
{

}