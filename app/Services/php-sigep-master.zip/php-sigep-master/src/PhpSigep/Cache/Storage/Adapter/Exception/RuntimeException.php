<?php

namespace PhpSigep\Cache\Storage\Adapter\Exception;

class RuntimeException extends \RuntimeException
{
}
