<?php
namespace PhpSigep;

/**
 * @author: Stavarengo
 */
class BootstrapException extends \Exception
{

} 